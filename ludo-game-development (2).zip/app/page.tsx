import { LudoApp } from "@/components/ludo-app"

export default function Page() {
  return <LudoApp />
}
