import { getApp, getApps, initializeApp, type FirebaseApp } from "firebase/app"
import { getAuth, type Auth } from "firebase/auth"
import { getDatabase, type Database } from "firebase/database"

const apiKey = process.env.NEXT_PUBLIC_FIREBASE_API_KEY?.trim() ?? ""

const firebaseConfig = {
  apiKey,
  authDomain: "coinrush-pro-ef37b.firebaseapp.com",
  databaseURL: "https://coinrush-pro-ef37b-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "coinrush-pro-ef37b",
}

// Firebase web API keys always start with "AIza"; anything else fails at runtime with auth/invalid-api-key.
export const firebaseConfigured = /^AIza[\w-]{30,}$/.test(apiKey)

function app(): FirebaseApp {
  if (!firebaseConfigured) throw new Error("Firebase is not configured")
  return getApps().length ? getApp() : initializeApp(firebaseConfig)
}

export function firebaseAuth(): Auth {
  return getAuth(app())
}

export function firebaseDb(): Database {
  return getDatabase(app())
}
