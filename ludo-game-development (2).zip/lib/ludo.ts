export type Color = "red" | "green" | "yellow" | "blue"
export type Controller = "human" | "bot" | "remote"

export const TURN_ORDER: Color[] = ["red", "green", "yellow", "blue"]

export const COLOR_HEX: Record<Color, { main: string; dark: string; light: string }> = {
  red: { main: "#e8202a", dark: "#a8141b", light: "#ff6b70" },
  green: { main: "#16a34a", dark: "#0d6b30", light: "#4ade80" },
  yellow: { main: "#ffd200", dark: "#c99a00", light: "#fff07a" },
  blue: { main: "#22a3ec", dark: "#0f6fae", light: "#7dd3fc" },
}

export const START: Record<Color, number> = { red: 0, green: 13, yellow: 26, blue: 39 }
export const STAR_INDICES = [8, 21, 34, 47]
export const SAFE = new Set<number>([0, 13, 26, 39, ...STAR_INDICES])
export const FINISH = 56
const LAST_TRACK = 50

type Cell = [row: number, col: number]

function buildTrack(): Cell[] {
  const t: Cell[] = []
  for (let r = 13; r >= 9; r--) t.push([r, 6])
  for (let c = 5; c >= 0; c--) t.push([8, c])
  t.push([7, 0])
  for (let c = 0; c <= 5; c++) t.push([6, c])
  for (let r = 5; r >= 0; r--) t.push([r, 6])
  t.push([0, 7])
  for (let r = 0; r <= 5; r++) t.push([r, 8])
  for (let c = 9; c <= 14; c++) t.push([6, c])
  t.push([7, 14])
  for (let c = 14; c >= 9; c--) t.push([8, c])
  for (let r = 9; r <= 14; r++) t.push([r, 8])
  t.push([14, 7])
  t.push([14, 6])
  return t
}

export const TRACK = buildTrack()

export const HOME_COLUMN: Record<Color, Cell[]> = {
  red: [13, 12, 11, 10, 9].map((r) => [r, 7] as Cell),
  green: [1, 2, 3, 4, 5].map((c) => [7, c] as Cell),
  yellow: [1, 2, 3, 4, 5].map((r) => [r, 7] as Cell),
  blue: [13, 12, 11, 10, 9].map((c) => [7, c] as Cell),
}

export const HOME_ORIGIN: Record<Color, { row: number; col: number; top: boolean }> = {
  green: { row: 0, col: 0, top: true },
  yellow: { row: 0, col: 9, top: true },
  red: { row: 9, col: 0, top: false },
  blue: { row: 9, col: 9, top: false },
}

export function homeBox(color: Color) {
  const o = HOME_ORIGIN[color]
  return { x: o.col + 0.9, y: o.row + (o.top ? 1.25 : 0.55), size: 4.2 }
}

export function baseSlots(color: Color): { x: number; y: number }[] {
  const b = homeBox(color)
  const a = b.size * 0.29
  const z = b.size * 0.71
  return [
    { x: b.x + a, y: b.y + a },
    { x: b.x + z, y: b.y + a },
    { x: b.x + a, y: b.y + z },
    { x: b.x + z, y: b.y + z },
  ]
}

const FINISH_SPOT: Record<Color, { x: number; y: number }> = {
  red: { x: 7.5, y: 8.55 },
  green: { x: 6.45, y: 7.5 },
  yellow: { x: 7.5, y: 6.45 },
  blue: { x: 8.55, y: 7.5 },
}

export function tokenPoint(color: Color, pos: number, idx: number) {
  if (pos < 0) return baseSlots(color)[idx]
  if (pos >= FINISH) {
    const f = FINISH_SPOT[color]
    const spread = (idx - 1.5) * 0.28
    const horizontal = color === "red" || color === "yellow"
    return horizontal ? { x: f.x + spread, y: f.y } : { x: f.x, y: f.y + spread }
  }
  const [r, c] = pos <= LAST_TRACK ? TRACK[(START[color] + pos) % 52] : HOME_COLUMN[color][pos - LAST_TRACK - 1]
  return { x: c + 0.5, y: r + 0.5 }
}

export interface GameState {
  players: Color[]
  tokens: Record<Color, number[]>
  turn: Color
  dice: number
  rolled: boolean
  sixes: number
  rollId: number
  sinceSix: Record<Color, number>
  finished: Color[]
  gameOver: boolean
  event: string
}

export function createGame(players: Color[]): GameState {
  const ordered = TURN_ORDER.filter((c) => players.includes(c))
  return {
    players: ordered,
    tokens: { red: [-1, -1, -1, -1], green: [-1, -1, -1, -1], yellow: [-1, -1, -1, -1], blue: [-1, -1, -1, -1] },
    turn: ordered[0],
    dice: 0,
    rolled: false,
    sixes: 0,
    rollId: 0,
    sinceSix: { red: 0, green: 0, yellow: 0, blue: 0 },
    finished: [],
    gameOver: false,
    event: "",
  }
}

/** Firebase drops empty arrays and zero-length values; restore a full state shape. */
export function normalizeState(raw: Partial<GameState> & { tokens?: Partial<Record<Color, number[]>> }): GameState {
  const base = createGame(raw.players ?? ["red", "yellow"])
  const tokens = { ...base.tokens }
  for (const c of TURN_ORDER) {
    const t = raw.tokens?.[c]
    if (t) tokens[c] = [0, 1, 2, 3].map((i) => (typeof t[i] === "number" ? t[i] : -1))
  }
  return {
    ...base,
    ...raw,
    players: raw.players ?? base.players,
    tokens,
    finished: raw.finished ?? [],
    dice: raw.dice ?? 0,
    rolled: !!raw.rolled,
    sixes: raw.sixes ?? 0,
    rollId: raw.rollId ?? 0,
    sinceSix: { ...base.sinceSix, ...raw.sinceSix },
    gameOver: !!raw.gameOver,
    event: raw.event ?? "",
  }
}

function absIndex(color: Color, pos: number) {
  return (START[color] + pos) % 52
}

function nextPlayer(state: GameState, finished: Color[]): Color {
  const list = state.players
  let i = list.indexOf(state.turn)
  for (let n = 0; n < list.length; n++) {
    i = (i + 1) % list.length
    if (!finished.includes(list[i])) return list[i]
  }
  return state.turn
}

export function getMovable(state: GameState): number[] {
  if (!state.rolled || state.gameOver || state.sixes >= 3) return []
  const d = state.dice
  return state.tokens[state.turn]
    .map((p, i) => ({ p, i }))
    .filter(({ p }) => (p === -1 ? d === 6 : p + d <= FINISH))
    .map(({ i }) => i)
}

export const PITY_ROLLS = 10

/** Pure random 1-6, except a 6 is guaranteed after PITY_ROLLS rolls without one. */
export function drawDie(state: GameState): number {
  if (state.sinceSix[state.turn] >= PITY_ROLLS) return 6
  return Math.floor(Math.random() * 6) + 1
}

export function rollDice(state: GameState, value: number): GameState {
  const sixes = value === 6 ? state.sixes + 1 : 0
  const sinceSix = { ...state.sinceSix, [state.turn]: value === 6 ? 0 : state.sinceSix[state.turn] + 1 }
  return {
    ...state,
    dice: value,
    rolled: true,
    sixes,
    sinceSix,
    rollId: state.rollId + 1,
    event: sixes >= 3 ? "Three sixes! Turn lost." : "",
  }
}

export function passTurn(state: GameState): GameState {
  return { ...state, turn: nextPlayer(state, state.finished), rolled: false, sixes: 0, dice: 0 }
}

function capturesAt(state: GameState, color: Color, newPos: number) {
  if (newPos > LAST_TRACK) return [] as [Color, number][]
  const abs = absIndex(color, newPos)
  if (SAFE.has(abs)) return []
  const hits: [Color, number][] = []
  for (const other of state.players) {
    if (other === color) continue
    state.tokens[other].forEach((p, i) => {
      if (p >= 0 && p <= LAST_TRACK && absIndex(other, p) === abs) hits.push([other, i])
    })
  }
  return hits
}

export function moveToken(state: GameState, idx: number): GameState {
  const color = state.turn
  const cur = state.tokens[color][idx]
  const newPos = cur === -1 ? 0 : cur + state.dice
  const tokens = Object.fromEntries(TURN_ORDER.map((c) => [c, [...state.tokens[c]]])) as Record<Color, number[]>
  tokens[color][idx] = newPos

  const hits = capturesAt(state, color, newPos)
  for (const [c, i] of hits) tokens[c][i] = -1

  const finished = [...state.finished]
  if (tokens[color].every((p) => p === FINISH) && !finished.includes(color)) finished.push(color)
  const remaining = state.players.filter((p) => !finished.includes(p))
  const gameOver = remaining.length <= 1
  if (gameOver) finished.push(...remaining)

  const after: GameState = { ...state, tokens, finished, gameOver }
  let event = ""
  if (hits.length) event = "cut"
  else if (newPos === FINISH) event = "home"

  if (gameOver) return { ...after, rolled: false, event }

  const extra = !finished.includes(color) && (state.dice === 6 || hits.length > 0 || newPos === FINISH)
  if (extra) return { ...after, rolled: false, event }
  return { ...passTurn(after), event }
}

export function chooseBotMove(state: GameState): number {
  const color = state.turn
  const moves = getMovable(state)
  let best = moves[0]
  let bestScore = -Infinity
  for (const i of moves) {
    const cur = state.tokens[color][i]
    const np = cur === -1 ? 0 : cur + state.dice
    let score = np * 0.5
    if (np === FINISH) score += 100
    if (capturesAt(state, color, np).length) score += 80
    if (cur === -1) score += 60
    if (np > LAST_TRACK && cur <= LAST_TRACK) score += 40
    if (np <= LAST_TRACK) {
      const abs = absIndex(color, np)
      if (SAFE.has(abs)) score += 25
      else if (inDanger(state, color, abs)) score -= 30
    }
    if (cur >= 0 && cur <= LAST_TRACK && inDanger(state, color, absIndex(color, cur))) score += 20
    if (score > bestScore) {
      bestScore = score
      best = i
    }
  }
  return best
}

function inDanger(state: GameState, color: Color, abs: number) {
  if (SAFE.has(abs)) return false
  return state.players.some(
    (o) =>
      o !== color &&
      state.tokens[o].some((p) => {
        if (p < 0 || p > LAST_TRACK) return false
        const gap = (abs - absIndex(o, p) + 52) % 52
        return gap >= 1 && gap <= 6
      }),
  )
}
