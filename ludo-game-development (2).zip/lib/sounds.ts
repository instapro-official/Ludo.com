let ctx: AudioContext | null = null

function audio(): AudioContext | null {
  if (typeof window === "undefined") return null
  try {
    ctx ??= new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)()
    if (ctx.state === "suspended") void ctx.resume()
    return ctx
  } catch {
    return null
  }
}

function click(ac: AudioContext, at: number, gain: number, freq: number) {
  const len = Math.floor(ac.sampleRate * 0.04)
  const buffer = ac.createBuffer(1, len, ac.sampleRate)
  const data = buffer.getChannelData(0)
  for (let i = 0; i < len; i++) data[i] = (Math.random() * 2 - 1) * (1 - i / len) ** 3
  const src = ac.createBufferSource()
  src.buffer = buffer
  const filter = ac.createBiquadFilter()
  filter.type = "bandpass"
  filter.frequency.value = freq
  filter.Q.value = 1.4
  const g = ac.createGain()
  g.gain.value = gain
  src.connect(filter).connect(g).connect(ac.destination)
  src.start(at)
}

export function playDiceRoll(durationMs = 800) {
  const ac = audio()
  if (!ac) return
  const start = ac.currentTime
  const end = durationMs / 1000
  let t = 0
  while (t < end - 0.08) {
    click(ac, start + t, 0.35 + Math.random() * 0.25, 1800 + Math.random() * 1600)
    t += 0.05 + Math.random() * 0.05
  }
  click(ac, start + end, 0.9, 900)
  click(ac, start + end + 0.09, 0.4, 1100)
}

export function playTokenStep() {
  const ac = audio()
  if (!ac) return
  const osc = ac.createOscillator()
  const g = ac.createGain()
  osc.type = "triangle"
  osc.frequency.setValueAtTime(660, ac.currentTime)
  osc.frequency.exponentialRampToValueAtTime(990, ac.currentTime + 0.08)
  g.gain.setValueAtTime(0.18, ac.currentTime)
  g.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + 0.15)
  osc.connect(g).connect(ac.destination)
  osc.start()
  osc.stop(ac.currentTime + 0.16)
}
