import { onValue, ref, runTransaction, set, update, serverTimestamp } from "firebase/database"
import { firebaseDb } from "./firebase"
import { createGame, type Color, type GameState } from "./ludo"

export interface RoomPlayer {
  uid: string
  name: string
}

export interface Room {
  host: string
  status: "waiting" | "playing"
  players?: Partial<Record<Color, RoomPlayer>>
  state?: GameState
}

const SEAT_ORDER: Color[] = ["red", "yellow", "green", "blue"]

function roomRef(code: string) {
  return ref(firebaseDb(), `ludo_rooms/${code}`)
}

function makeCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
  return Array.from({ length: 6 }, () => chars[Math.floor(Math.random() * chars.length)]).join("")
}

export async function createRoom(user: RoomPlayer) {
  const code = makeCode()
  await set(roomRef(code), {
    host: user.uid,
    status: "waiting",
    createdAt: serverTimestamp(),
    players: { red: user },
  })
  return code
}

export async function joinRoom(code: string, user: RoomPlayer) {
  const result = await runTransaction(roomRef(code), (room: Room | null) => {
    if (!room) return room
    const players = room.players ?? {}
    if (Object.values(players).some((p) => p?.uid === user.uid)) return room
    if (room.status !== "waiting") return undefined
    const seat = SEAT_ORDER.find((c) => !players[c])
    if (!seat) return undefined
    return { ...room, players: { ...players, [seat]: user } }
  })
  const room = result.snapshot.val() as Room | null
  if (!room) throw new Error("Room not found.")
  const mine = Object.entries(room.players ?? {}).find(([, p]) => p?.uid === user.uid)
  if (!mine) throw new Error("Room is full or the game already started.")
  return mine[0] as Color
}

export async function startRoom(code: string, colors: Color[]) {
  await update(roomRef(code), { status: "playing", state: createGame(colors) })
}

export async function pushRoomState(code: string, state: GameState) {
  await set(ref(firebaseDb(), `ludo_rooms/${code}/state`), state)
}

export function subscribeRoom(code: string, cb: (room: Room | null) => void) {
  return onValue(roomRef(code), (snap) => cb(snap.val()))
}
