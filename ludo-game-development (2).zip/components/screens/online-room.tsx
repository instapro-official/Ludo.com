"use client"

import { useCallback, useEffect, useState } from "react"
import { ArrowLeft, Copy } from "lucide-react"
import { createRoom, joinRoom, pushRoomState, startRoom, subscribeRoom, type Room, type RoomPlayer } from "@/lib/rooms"
import { TURN_ORDER, normalizeState, type Color, type Controller, type GameState } from "@/lib/ludo"
import { GameScreen } from "@/components/ludo/game-screen"
import { PinToken } from "@/components/ludo/pin-token"
import { ScreenShell } from "./screen-shell"

export function OnlineLobby({ user, onExit }: { user: RoomPlayer; onExit: () => void }) {
  const [code, setCode] = useState<string | null>(null)
  const [input, setInput] = useState("")
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState("")

  const act = async (fn: () => Promise<string>) => {
    setBusy(true)
    setError("")
    try {
      setCode(await fn())
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong")
    } finally {
      setBusy(false)
    }
  }

  if (code) return <OnlineRoom code={code} user={user} onExit={onExit} />

  return (
    <ScreenShell>
      <button type="button" onClick={onExit} className="mb-6 flex items-center gap-2 self-start font-semibold text-white">
        <ArrowLeft className="h-5 w-5" /> Back
      </button>
      <h1 className="text-3xl font-bold text-white">Play Online</h1>
      <button
        type="button"
        disabled={busy}
        onClick={() => act(() => createRoom(user))}
        className="mt-8 w-full rounded-2xl bg-gradient-to-b from-[#ffd84d] to-[#ffb300] py-4 text-xl font-bold text-[#7a3d00] shadow-[0_6px_0_#b45309] disabled:opacity-70"
      >
        CREATE ROOM
      </button>
      <div className="my-6 flex w-full items-center gap-3 text-white/70">
        <span className="h-px flex-1 bg-white/40" /> OR <span className="h-px flex-1 bg-white/40" />
      </div>
      <form
        className="flex w-full flex-col gap-3"
        onSubmit={(e) => {
          e.preventDefault()
          const c = input.trim().toUpperCase()
          if (c) act(async () => (await joinRoom(c, user), c))
        }}
      >
        <label htmlFor="room-code" className="sr-only">
          Room code
        </label>
        <input
          id="room-code"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="ENTER ROOM CODE"
          maxLength={6}
          autoComplete="off"
          className="w-full rounded-2xl border-2 border-[#f5c518] bg-white/95 px-4 py-4 text-center text-xl font-bold tracking-[0.3em] text-[#123c94] uppercase outline-none placeholder:text-base placeholder:tracking-widest placeholder:text-[#123c94]/50"
        />
        <button
          type="submit"
          disabled={busy || !input.trim()}
          className="w-full rounded-2xl bg-white py-4 text-xl font-bold text-[#123c94] shadow-[0_6px_0_#9ca3af] disabled:opacity-60"
        >
          JOIN ROOM
        </button>
      </form>
      {error && (
        <p className="mt-4 rounded-xl bg-black/40 p-3 text-center text-sm text-white" role="alert">
          {error}
        </p>
      )}
    </ScreenShell>
  )
}

function OnlineRoom({ code, user, onExit }: { code: string; user: RoomPlayer; onExit: () => void }) {
  const [room, setRoom] = useState<Room | null | undefined>(undefined)

  useEffect(() => subscribeRoom(code, setRoom), [code])

  const onChange = useCallback((next: GameState) => {
    pushRoomState(code, next)
  }, [code])

  if (room === undefined) {
    return (
      <ScreenShell>
        <p className="text-white">Connecting...</p>
      </ScreenShell>
    )
  }
  if (room === null) {
    return (
      <ScreenShell>
        <p className="text-white">Room not found.</p>
        <button type="button" onClick={onExit} className="mt-4 font-semibold text-[#ffd84d] underline">
          Back
        </button>
      </ScreenShell>
    )
  }

  const players = room.players ?? {}
  const seated = TURN_ORDER.filter((c) => players[c])
  const myColor = seated.find((c) => players[c]?.uid === user.uid)

  if (room.status === "playing" && room.state) {
    const state = normalizeState(room.state)
    const names = Object.fromEntries(
      TURN_ORDER.map((c) => [c, c === myColor ? "You" : (players[c]?.name ?? "")]),
    ) as Record<Color, string>
    const controllers = Object.fromEntries(
      TURN_ORDER.map((c) => [c, c === myColor ? "human" : "remote"]),
    ) as Record<Color, Controller>
    return <GameScreen state={state} onChange={onChange} names={names} controllers={controllers} onExit={onExit} />
  }

  const isHost = room.host === user.uid

  return (
    <ScreenShell>
      <button type="button" onClick={onExit} className="mb-6 flex items-center gap-2 self-start font-semibold text-white">
        <ArrowLeft className="h-5 w-5" /> Leave
      </button>
      <p className="text-sm font-semibold uppercase tracking-widest text-white/80">Room code</p>
      <button
        type="button"
        onClick={() => navigator.clipboard?.writeText(code)}
        className="mt-2 flex items-center gap-3 rounded-2xl border-2 border-[#f5c518] bg-white px-6 py-3 text-3xl font-bold tracking-[0.3em] text-[#123c94]"
        aria-label={`Copy room code ${code}`}
      >
        {code}
        <Copy className="h-5 w-5" />
      </button>
      <ul className="mt-8 flex w-full flex-col gap-3">
        {(["red", "yellow", "green", "blue"] as Color[]).map((c) => (
          <li key={c} className="flex items-center gap-3 rounded-xl bg-white/15 px-4 py-3 text-white">
            <PinToken color={c} className="h-9 w-7" />
            <span className="font-semibold">{players[c] ? players[c]?.name : "Waiting..."}</span>
            {players[c]?.uid === room.host && <span className="ml-auto text-xs font-bold text-[#ffd84d]">HOST</span>}
          </li>
        ))}
      </ul>
      {isHost ? (
        <button
          type="button"
          disabled={seated.length < 2}
          onClick={() => startRoom(code, seated)}
          className="mt-8 w-full rounded-2xl bg-gradient-to-b from-[#ffd84d] to-[#ffb300] py-4 text-xl font-bold text-[#7a3d00] shadow-[0_6px_0_#b45309] disabled:opacity-60"
        >
          {seated.length < 2 ? "Waiting for players..." : "START GAME"}
        </button>
      ) : (
        <p className="mt-8 text-white/80">Waiting for host to start...</p>
      )}
    </ScreenShell>
  )
}
