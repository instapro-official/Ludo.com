import type { ReactNode } from "react"

export function ScreenShell({ children }: { children: ReactNode }) {
  return (
    <main className="relative flex min-h-dvh flex-col items-center justify-center overflow-hidden bg-[#0b3a8c] px-5 py-10">
      <div
        className="pointer-events-none absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: "url(/images/bg-dice.png)" }}
        aria-hidden="true"
      />
      <div className="relative flex w-full max-w-sm flex-col items-center">{children}</div>
    </main>
  )
}

export function LudoLogo() {
  const letters = [
    { l: "L", c: "#e8202a" },
    { l: "U", c: "#16a34a" },
    { l: "D", c: "#ffd200" },
    { l: "O", c: "#22a3ec" },
  ]
  return (
    <div className="flex flex-col items-center">
      <div className="grid h-24 w-24 grid-cols-2 grid-rows-2 overflow-hidden rounded-2xl border-4 border-white shadow-xl">
        <span className="bg-[#16a34a]" />
        <span className="bg-[#ffd200]" />
        <span className="bg-[#e8202a]" />
        <span className="bg-[#22a3ec]" />
      </div>
      <h1 className="mt-4 flex gap-1 text-6xl font-bold tracking-wide" aria-label="Ludo">
        {letters.map(({ l, c }) => (
          <span
            key={l}
            aria-hidden="true"
            style={{ color: c, WebkitTextStroke: "2px white", textShadow: "0 4px 0 rgba(0,0,0,0.35)" }}
          >
            {l}
          </span>
        ))}
      </h1>
      <p className="mt-1 text-sm font-semibold uppercase tracking-[0.3em] text-white/80">Dice Battle</p>
    </div>
  )
}
