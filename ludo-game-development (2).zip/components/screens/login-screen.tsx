"use client"

import { useState } from "react"
import { GoogleAuthProvider, signInAnonymously, signInWithPopup } from "firebase/auth"
import { firebaseAuth, firebaseConfigured } from "@/lib/firebase"
import { LudoLogo, ScreenShell } from "./screen-shell"

export function LoginScreen({ onOffline }: { onOffline: () => void }) {
  const [busy, setBusy] = useState<"guest" | "google" | null>(null)
  const [error, setError] = useState("")

  const run = async (kind: "guest" | "google") => {
    if (kind === "guest") {
      onOffline()
      if (firebaseConfigured) {
        try {
          await signInAnonymously(firebaseAuth())
        } catch {}
      }
      return
    }
    setError("")
    if (!firebaseConfigured) {
      setError("Online login is unavailable right now. You can still play offline.")
      return
    }
    setBusy(kind)
    try {
      await signInWithPopup(firebaseAuth(), new GoogleAuthProvider())
    } catch {
      setError("Google sign-in failed. You can still play offline.")
    } finally {
      setBusy(null)
    }
  }

  return (
    <ScreenShell>
      <LudoLogo />
      <div className="mt-12 flex w-full flex-col gap-4">
        <button
          type="button"
          onClick={() => run("guest")}
          disabled={busy !== null}
          className="rounded-2xl border-2 border-white/70 bg-gradient-to-b from-[#ffd84d] to-[#ffb300] py-4 text-xl font-bold text-[#7a3d00] shadow-[0_6px_0_#b45309] transition active:translate-y-1 active:shadow-[0_2px_0_#b45309] disabled:opacity-70"
        >
          PLAY AS GUEST
        </button>
        <button
          type="button"
          onClick={() => run("google")}
          disabled={busy !== null}
          className="flex items-center justify-center gap-3 rounded-2xl border-2 border-white/70 bg-white py-4 text-xl font-bold text-[#123c94] shadow-[0_6px_0_#9ca3af] transition active:translate-y-1 active:shadow-[0_2px_0_#9ca3af] disabled:opacity-70"
        >
          <svg viewBox="0 0 48 48" className="h-6 w-6" aria-hidden="true">
            <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3 0 5.8 1.2 7.9 3l5.7-5.7C34 6 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z" />
            <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3 0 5.8 1.2 7.9 3l5.7-5.7C34 6 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z" />
            <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z" />
            <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z" />
          </svg>
          {busy === "google" ? "Opening..." : "LOGIN WITH GOOGLE"}
        </button>
        {error && (
          <p className="rounded-xl bg-black/40 p-3 text-center text-sm text-white" role="alert">
            {error}
          </p>
        )}
        <button type="button" onClick={onOffline} className="mt-1 font-semibold text-[#ffd84d] underline">
          Continue offline instead
        </button>
      </div>
    </ScreenShell>
  )
}
