"use client"

import { useState } from "react"
import { Bot, Globe, LogOut, Users } from "lucide-react"
import { LudoLogo, ScreenShell } from "./screen-shell"

interface ModeSelectProps {
  userName: string
  online: boolean
  onComputer: () => void
  onOffline: (count: 2 | 3 | 4) => void
  onOnline: () => void
  onSignOut: () => void
}

const cardClass =
  "flex w-full items-center gap-4 rounded-2xl border-2 border-[#f5c518] bg-gradient-to-b from-[#2f7de1] to-[#1747a6] p-4 text-left text-white shadow-[0_5px_0_#0b2a6b] transition active:translate-y-1 active:shadow-[0_1px_0_#0b2a6b] disabled:opacity-50"

export function ModeSelect({ userName, online, onComputer, onOffline, onOnline, onSignOut }: ModeSelectProps) {
  const [pickCount, setPickCount] = useState(false)

  return (
    <ScreenShell>
      <LudoLogo />
      <p className="mt-6 text-center text-white">
        Welcome, <span className="font-bold text-[#ffd84d]">{userName}</span>
      </p>
      <div className="mt-6 flex w-full flex-col gap-4">
        <button type="button" onClick={onComputer} className={cardClass}>
          <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-[#e8202a]">
            <Bot className="h-7 w-7" />
          </span>
          <span>
            <span className="block text-lg font-bold">vs Computer</span>
            <span className="text-sm text-white/80">Play against 3 bots</span>
          </span>
        </button>

        <div>
          <button type="button" onClick={() => setPickCount((v) => !v)} className={cardClass} aria-expanded={pickCount}>
            <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-[#16a34a]">
              <Users className="h-7 w-7" />
            </span>
            <span>
              <span className="block text-lg font-bold">vs Friends Offline</span>
              <span className="text-sm text-white/80">2-4 players on one device</span>
            </span>
          </button>
          {pickCount && (
            <div className="mt-3 grid grid-cols-3 gap-3">
              {([2, 3, 4] as const).map((n) => (
                <button
                  key={n}
                  type="button"
                  onClick={() => onOffline(n)}
                  className="rounded-xl bg-gradient-to-b from-[#ffd84d] to-[#ffb300] py-3 text-lg font-bold text-[#7a3d00] shadow-[0_4px_0_#b45309]"
                >
                  {n} Players
                </button>
              ))}
            </div>
          )}
        </div>

        <button type="button" onClick={onOnline} disabled={!online} className={cardClass}>
          <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-[#22a3ec]">
            <Globe className="h-7 w-7" />
          </span>
          <span>
            <span className="block text-lg font-bold">vs Friends Online</span>
            <span className="text-sm text-white/80">{online ? "Create or join with room code" : "Sign in to play online"}</span>
          </span>
        </button>
      </div>

      <button type="button" onClick={onSignOut} className="mt-8 flex items-center gap-2 text-sm font-semibold text-white/80">
        <LogOut className="h-4 w-4" />
        Sign out
      </button>
    </ScreenShell>
  )
}
