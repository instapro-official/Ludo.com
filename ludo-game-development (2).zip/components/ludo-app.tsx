"use client"

import { useEffect, useState } from "react"
import { onAuthStateChanged, signOut } from "firebase/auth"
import { firebaseAuth, firebaseConfigured } from "@/lib/firebase"
import { createGame, TURN_ORDER, type Color, type Controller, type GameState } from "@/lib/ludo"
import { GameScreen } from "./ludo/game-screen"
import { LoginScreen } from "./screens/login-screen"
import { ModeSelect } from "./screens/mode-select"
import { OnlineLobby } from "./screens/online-room"

type Screen = "login" | "mode" | "game" | "online"

interface LocalConfig {
  names: Record<Color, string>
  controllers: Record<Color, Controller>
  players: Color[]
}

const COMPUTER_NAMES: Record<Color, string> = {
  red: "You",
  green: "Computer 2",
  yellow: "Computer 3",
  blue: "Computer 4",
}

const OFFLINE_SEATS: Record<2 | 3 | 4, Color[]> = {
  2: ["red", "yellow"],
  3: ["red", "green", "yellow"],
  4: ["red", "green", "yellow", "blue"],
}

export function LudoApp() {
  const [screen, setScreen] = useState<Screen>("login")
  const [user, setUser] = useState<{ uid: string; name: string } | null>(null)
  const [config, setConfig] = useState<LocalConfig | null>(null)
  const [game, setGame] = useState<GameState | null>(null)

  useEffect(() => {
    if (!firebaseConfigured) return
    try {
      return onAuthStateChanged(firebaseAuth(), (u) => {
        if (u) {
          setUser({ uid: u.uid, name: u.displayName || `Guest ${u.uid.slice(0, 4).toUpperCase()}` })
          setScreen((s) => (s === "login" ? "mode" : s))
        } else {
          setUser(null)
        }
      })
    } catch {
      return undefined
    }
  }, [])

  const startLocal = (cfg: LocalConfig) => {
    setConfig(cfg)
    setGame(createGame(cfg.players))
    setScreen("game")
  }

  const playComputer = () =>
    startLocal({
      names: COMPUTER_NAMES,
      players: [...TURN_ORDER],
      controllers: { red: "human", green: "bot", yellow: "bot", blue: "bot" },
    })

  const playOffline = (count: 2 | 3 | 4) => {
    const seats = OFFLINE_SEATS[count]
    const names = {} as Record<Color, string>
    TURN_ORDER.forEach((c) => {
      names[c] = seats.includes(c) ? `Player ${seats.indexOf(c) + 1}` : ""
    })
    startLocal({
      names,
      players: seats,
      controllers: { red: "human", green: "human", yellow: "human", blue: "human" },
    })
  }

  const handleSignOut = async () => {
    try {
      if (firebaseConfigured) await signOut(firebaseAuth())
    } catch {}
    setUser(null)
    setScreen("login")
  }

  if (screen === "login") return <LoginScreen onOffline={() => setScreen("mode")} />

  if (screen === "online" && user) return <OnlineLobby user={user} onExit={() => setScreen("mode")} />

  if (screen === "game" && config && game) {
    return (
      <GameScreen
        state={game}
        onChange={setGame}
        names={config.names}
        controllers={config.controllers}
        onExit={() => setScreen("mode")}
        onRestart={() => setGame(createGame(config.players))}
      />
    )
  }

  return (
    <ModeSelect
      userName={user?.name ?? "Player"}
      online={!!user}
      onComputer={playComputer}
      onOffline={playOffline}
      onOnline={() => setScreen("online")}
      onSignOut={handleSignOut}
    />
  )
}
