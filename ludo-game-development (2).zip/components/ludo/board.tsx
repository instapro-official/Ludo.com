"use client"

import { useEffect, useState } from "react"
import {
  COLOR_HEX,
  HOME_COLUMN,
  HOME_ORIGIN,
  START,
  STAR_INDICES,
  TRACK,
  TURN_ORDER,
  baseSlots,
  homeBox,
  tokenPoint,
  type Color,
} from "@/lib/ludo"
import { PinToken } from "./pin-token"

interface BoardProps {
  players: Color[]
  tokens: Record<Color, number[]>
  names: Record<Color, string>
  movable: number[]
  turn: Color
  onTokenClick: (idx: number) => void
}

const STEP_MS = 140

function useSteppedTokens(tokens: Record<Color, number[]>) {
  const [shown, setShown] = useState(tokens)
  useEffect(() => {
    const id = setInterval(() => {
      setShown((prev) => {
        let changed = false
        const next = {} as Record<Color, number[]>
        for (const c of TURN_ORDER) {
          next[c] = prev[c].map((p, i) => {
            const target = tokens[c][i]
            if (p === target) return p
            changed = true
            return target > p && p >= 0 ? p + 1 : target
          })
        }
        if (!changed) clearInterval(id)
        return changed ? next : prev
      })
    }, STEP_MS)
    return () => clearInterval(id)
  }, [tokens])
  return shown
}

function starPoints(cx: number, cy: number, outer: number, inner: number) {
  return Array.from({ length: 10 }, (_, i) => {
    const r = i % 2 === 0 ? outer : inner
    const a = (Math.PI / 5) * i - Math.PI / 2
    return `${cx + r * Math.cos(a)},${cy + r * Math.sin(a)}`
  }).join(" ")
}

const ARROWS: { color: Color; cell: [number, number]; rotate: number }[] = [
  { color: "green", cell: [7, 0], rotate: 0 },
  { color: "yellow", cell: [0, 7], rotate: 90 },
  { color: "blue", cell: [7, 14], rotate: 180 },
  { color: "red", cell: [14, 7], rotate: 270 },
]

function BoardSvg({ names, players }: { names: Record<Color, string>; players: Color[] }) {
  const colored = new Map<string, string>()
  for (const c of TURN_ORDER) {
    for (const [r, col] of HOME_COLUMN[c]) colored.set(`${r}-${col}`, COLOR_HEX[c].main)
    const [sr, sc] = TRACK[START[c]]
    colored.set(`${sr}-${sc}`, COLOR_HEX[c].main)
  }
  const cells = [...TRACK, ...TURN_ORDER.flatMap((c) => HOME_COLUMN[c])]

  return (
    <svg viewBox="0 0 15 15" className="absolute inset-0 h-full w-full" aria-hidden="true">
      <rect width="15" height="15" fill="#ffffff" />
      {cells.map(([r, c]) => (
        <rect
          key={`${r}-${c}`}
          x={c}
          y={r}
          width="1"
          height="1"
          fill={colored.get(`${r}-${c}`) ?? "#ffffff"}
          stroke="#8e939b"
          strokeWidth="0.035"
        />
      ))}

      {STAR_INDICES.map((i) => {
        const [r, c] = TRACK[i]
        return (
          <polygon
            key={i}
            points={starPoints(c + 0.5, r + 0.5, 0.38, 0.16)}
            fill="#ffffff"
            stroke="#8e939b"
            strokeWidth="0.05"
            strokeLinejoin="round"
          />
        )
      })}

      {ARROWS.map(({ color, cell: [r, c], rotate }) => (
        <g key={color} transform={`translate(${c + 0.5} ${r + 0.5}) rotate(${rotate})`}>
          <path
            d="M-0.32 0 H0.28 M0.08 -0.2 L0.3 0 L0.08 0.2"
            fill="none"
            stroke={COLOR_HEX[color].main}
            strokeWidth="0.09"
            strokeLinecap="round"
            strokeLinejoin="round"
          />
        </g>
      ))}

      {TURN_ORDER.map((color) => {
        const o = HOME_ORIGIN[color]
        const box = homeBox(color)
        const hex = COLOR_HEX[color]
        const active = players.includes(color)
        return (
          <g key={color}>
            <rect x={o.col} y={o.row} width="6" height="6" fill={hex.main} stroke={hex.dark} strokeWidth="0.08" />
            <rect
              x={box.x + 0.06}
              y={box.y + 0.08}
              width={box.size}
              height={box.size}
              rx="0.12"
              fill="rgba(0,0,0,0.25)"
            />
            <rect x={box.x} y={box.y} width={box.size} height={box.size} rx="0.12" fill="#ffffff" />
            {baseSlots(color).map((s, i) => (
              <circle key={i} cx={s.x} cy={s.y} r="0.62" fill={hex.main} opacity={active ? 1 : 0.55} />
            ))}
            <text
              x={o.col + 3}
              y={o.top ? o.row + 0.9 : o.row + 5.55}
              textAnchor="middle"
              fontSize="0.62"
              fontWeight="700"
              fill="#ffffff"
              stroke="rgba(0,0,0,0.45)"
              strokeWidth="0.07"
              paintOrder="stroke"
              style={{ fontFamily: "var(--font-fredoka), sans-serif" }}
            >
              {names[color]}
            </text>
          </g>
        )
      })}

      <polygon points="6,6 9,6 7.5,7.5" fill={COLOR_HEX.yellow.main} />
      <polygon points="9,6 9,9 7.5,7.5" fill={COLOR_HEX.blue.main} />
      <polygon points="6,9 9,9 7.5,7.5" fill={COLOR_HEX.red.main} />
      <polygon points="6,6 6,9 7.5,7.5" fill={COLOR_HEX.green.main} />
      <path d="M6 6 L9 9 M9 6 L6 9" stroke="rgba(0,0,0,0.15)" strokeWidth="0.03" />
      <rect width="15" height="15" fill="none" stroke="#374151" strokeWidth="0.1" />
    </svg>
  )
}

export function Board({ players, tokens, names, movable, turn, onTokenClick }: BoardProps) {
  const shown = useSteppedTokens(tokens)

  const items = players.flatMap((color) =>
    shown[color].map((pos, idx) => ({ color, idx, pos, pt: tokenPoint(color, pos, idx) })),
  )
  const groups = new Map<string, number>()
  const placed = items.map((it) => {
    const key = it.pos < 0 ? `${it.color}-base-${it.idx}` : `${it.pt.x.toFixed(2)}-${it.pt.y.toFixed(2)}`
    const n = groups.get(key) ?? 0
    groups.set(key, n + 1)
    return { ...it, key, order: n }
  })

  return (
    <div className="relative aspect-square w-full overflow-hidden rounded-sm shadow-[0_8px_24px_rgba(0,0,0,0.45)] ring-4 ring-white/90">
      <BoardSvg names={names} players={players} />
      {placed.map(({ color, idx, pos, pt, key, order }) => {
        const count = groups.get(key) ?? 1
        const stacked = count > 1
        const offset = stacked ? (order - (count - 1) / 2) * 0.32 : 0
        const canMove = color === turn && movable.includes(idx)
        const scale = stacked ? 0.78 : 1
        return (
          <button
            key={`${color}-${idx}`}
            type="button"
            disabled={!canMove}
            onClick={() => onTokenClick(idx)}
            aria-label={`${color} token ${idx + 1}${canMove ? ", can move" : ""}`}
            className="absolute flex items-end justify-center transition-[left,top] duration-150 ease-out disabled:cursor-default"
            style={{
              left: `${((pt.x + offset) / 15) * 100}%`,
              top: `${(pt.y / 15) * 100}%`,
              width: `${(0.95 / 15) * 100}%`,
              height: `${(1.28 / 15) * 100}%`,
              transform: `translate(-50%, -84%) scale(${scale})`,
              transformOrigin: "50% 92%",
              zIndex: canMove ? 50 : Math.round(pt.y * 2) + order,
            }}
          >
            {canMove && (
              <span className="token-glow pointer-events-none absolute -inset-[35%] -z-10 rounded-full" aria-hidden="true" />
            )}
            <PinToken
              color={color}
              className={`h-full w-full drop-shadow-[0_2px_1.5px_rgba(0,0,0,0.45)] ${canMove ? "token-bounce" : ""} ${
                pos >= 56 ? "opacity-90" : ""
              }`}
            />
          </button>
        )
      })}
    </div>
  )
}
