"use client"

import { useEffect, useState } from "react"

const PIPS: Record<number, number[]> = {
  1: [4],
  2: [0, 8],
  3: [0, 4, 8],
  4: [0, 2, 6, 8],
  5: [0, 2, 4, 6, 8],
  6: [0, 2, 3, 5, 6, 8],
}

function randomFace(prev: number) {
  let f = prev
  while (f === prev) f = 1 + Math.floor(Math.random() * 6)
  return f
}

export function Dice({ value, rollId, rolling }: { value: number; rollId: number; rolling: boolean }) {
  const [spinFace, setSpinFace] = useState(1)

  useEffect(() => {
    if (!rolling) return
    const id = setInterval(() => setSpinFace(randomFace), 70)
    return () => clearInterval(id)
  }, [rolling])

  const face = rolling ? spinFace : value || 1
  const animation = rolling ? "dice-spin" : value ? "dice-land" : ""

  return (
    <div
      key={rolling ? "spin" : `land-${rollId}`}
      className={`${animation} grid aspect-square w-full grid-cols-3 grid-rows-3 gap-[6%] rounded-[18%] bg-gradient-to-br from-white to-zinc-200 p-[16%] shadow-[inset_0_-3px_0_rgba(0,0,0,0.18),0_3px_6px_rgba(0,0,0,0.35)]`}
      role="img"
      aria-label={rolling ? "Rolling dice" : value ? `Dice shows ${value}` : "Dice"}
    >
      {Array.from({ length: 9 }, (_, i) => (
        <span
          key={i}
          className={PIPS[face].includes(i) ? "rounded-full bg-zinc-900 shadow-[inset_0_1px_1px_rgba(255,255,255,0.3)]" : ""}
        />
      ))}
    </div>
  )
}
