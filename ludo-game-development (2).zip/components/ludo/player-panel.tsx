import type { Color } from "@/lib/ludo"
import { Dice } from "./dice"
import { PinToken } from "./pin-token"

interface PlayerPanelProps {
  color: Color
  side: "left" | "right"
  inGame: boolean
  isTurn: boolean
  canRoll: boolean
  dice: number
  rollId: number
  rolling: boolean
  onRoll: () => void
  name: string
}

function TurnArrow({ pointLeft }: { pointLeft: boolean }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={`turn-arrow h-8 w-8 shrink-0 drop-shadow-[0_2px_2px_rgba(0,0,0,0.5)] sm:h-10 sm:w-10 ${pointLeft ? "" : "rotate-180"}`}
      aria-hidden="true"
    >
      <path d="M4 16 L18 4 V11 H29 V21 H18 V28 Z" fill="#ffb300" stroke="#b45309" strokeWidth="1.6" strokeLinejoin="round" />
      <path d="M8 16 L17 8.5 V13 H27 V16 Z" fill="#ffe27a" opacity="0.8" />
    </svg>
  )
}

export function PlayerPanel({ color, side, inGame, isTurn, canRoll, dice, rollId, rolling, onRoll, name }: PlayerPanelProps) {
  const pin = (
    <div className="flex h-full w-11 items-center justify-center bg-gradient-to-b from-[#2f7de1] to-[#1747a6] sm:w-14">
      {inGame && <PinToken color={color} className="h-[78%] w-auto drop-shadow-[0_2px_1px_rgba(0,0,0,0.4)]" />}
    </div>
  )
  const diceBox = (
    <button
      type="button"
      onClick={onRoll}
      disabled={!canRoll}
      aria-label={canRoll ? `Roll dice for ${name}` : `${name} dice`}
      className={`flex h-full w-14 items-center justify-center bg-gradient-to-b from-[#fbd3d6] to-[#e9a9ae] p-2 sm:w-[4.5rem] ${
        canRoll ? "tap-pulse cursor-pointer" : "cursor-default"
      }`}
    >
      {isTurn && <Dice value={dice} rollId={rollId} rolling={rolling} />}
    </button>
  )

  return (
    <div className={`flex items-center gap-1 ${side === "right" ? "flex-row-reverse" : ""} ${inGame ? "" : "opacity-40"}`}>
      <div
        className={`flex h-14 overflow-hidden rounded-md border-2 border-[#f5c518] shadow-[0_3px_8px_rgba(0,0,0,0.5)] sm:h-[4.5rem] ${
          side === "right" ? "flex-row-reverse" : ""
        } ${isTurn ? "ring-2 ring-white" : ""}`}
      >
        {pin}
        {diceBox}
      </div>
      <div className="w-8 sm:w-10">{isTurn && <TurnArrow pointLeft={side === "left"} />}</div>
    </div>
  )
}
