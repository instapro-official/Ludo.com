import { COLOR_HEX, type Color } from "@/lib/ludo"

export function PinToken({ color, className }: { color: Color; className?: string }) {
  const c = COLOR_HEX[color]
  const id = `pin-${color}`
  return (
    <svg viewBox="0 0 40 54" className={className} aria-hidden="true">
      <defs>
        <radialGradient id={`${id}-dot`} cx="35%" cy="30%" r="75%">
          <stop offset="0%" stopColor={c.light} />
          <stop offset="55%" stopColor={c.main} />
          <stop offset="100%" stopColor={c.dark} />
        </radialGradient>
        <linearGradient id={`${id}-body`} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#ffffff" />
          <stop offset="100%" stopColor="#c9ced6" />
        </linearGradient>
      </defs>
      <ellipse cx="20" cy="47" rx="12.5" ry="5.2" fill="none" stroke="#9b1018" strokeWidth="3.4" />
      <ellipse cx="20" cy="47" rx="12.5" ry="5.2" fill="none" stroke="#ff4d55" strokeWidth="1.2" />
      <path
        d="M20 47 C14 37 5 30 5 18 A15 15 0 1 1 35 18 C35 30 26 37 20 47 Z"
        fill={`url(#${id}-body)`}
        stroke="#5b6270"
        strokeWidth="1.6"
      />
      <circle cx="20" cy="18" r="9.5" fill={`url(#${id}-dot)`} stroke={c.dark} strokeWidth="1" />
      <ellipse cx="16.5" cy="14" rx="3.4" ry="2.2" fill="#ffffff" opacity="0.7" />
    </svg>
  )
}
