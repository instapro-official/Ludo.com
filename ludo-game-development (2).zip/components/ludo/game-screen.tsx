"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import { LogOut, Trophy } from "lucide-react"
import { playDiceRoll, playTokenStep } from "@/lib/sounds"
import {
  chooseBotMove,
  drawDie,
  getMovable,
  moveToken,
  passTurn,
  rollDice,
  type Color,
  type Controller,
  type GameState,
} from "@/lib/ludo"
import { Board } from "./board"
import { PlayerPanel } from "./player-panel"

interface GameScreenProps {
  state: GameState
  onChange: (next: GameState) => void
  names: Record<Color, string>
  controllers: Record<Color, Controller>
  onExit: () => void
  onRestart?: () => void
}

const BOT_DELAY = 1000
const ROLL_DURATION = 800

export function GameScreen({ state, onChange, names, controllers, onExit, onRestart }: GameScreenProps) {
  const [rolling, setRolling] = useState(false)
  const stateRef = useRef(state)
  stateRef.current = state

  const ctrl = controllers[state.turn]
  const isAuthority = ctrl !== "remote"
  const movable = getMovable(state)
  const humanTurn = ctrl === "human" && !state.gameOver
  const canRoll = humanTurn && !state.rolled && !rolling

  const startRoll = useCallback(() => {
    setRolling(true)
    playDiceRoll(ROLL_DURATION)
    setTimeout(() => {
      setRolling(false)
      onChange(rollDice(stateRef.current, drawDie(stateRef.current)))
    }, ROLL_DURATION)
  }, [onChange])

  const move = useCallback(
    (s: GameState, idx: number) => {
      playTokenStep()
      onChange(moveToken(s, idx))
    },
    [onChange],
  )

  useEffect(() => {
    if (state.gameOver || !isAuthority || rolling) return
    let timer: ReturnType<typeof setTimeout> | undefined
    const moves = getMovable(state)
    if (!state.rolled) {
      if (ctrl === "bot") timer = setTimeout(startRoll, BOT_DELAY)
    } else if (moves.length === 0) {
      timer = setTimeout(() => onChange(passTurn(state)), 1100)
    } else if (ctrl === "bot") {
      timer = setTimeout(() => move(state, chooseBotMove(state)), 750)
    } else {
      const positions = new Set(moves.map((i) => state.tokens[state.turn][i]))
      if (positions.size === 1) timer = setTimeout(() => move(state, moves[0]), 550)
    }
    return () => clearTimeout(timer)
  }, [state, ctrl, isAuthority, rolling, onChange, startRoll, move])

  const handleRoll = () => {
    if (canRoll) startRoll()
  }
  const handleMove = (idx: number) => {
    if (humanTurn && state.rolled && !rolling && movable.includes(idx)) move(state, idx)
  }

  const panel = (color: Color, side: "left" | "right") => (
    <PlayerPanel
      color={color}
      side={side}
      inGame={state.players.includes(color)}
      isTurn={state.turn === color && !state.gameOver}
      canRoll={canRoll && state.turn === color}
      dice={state.dice}
      rollId={state.rollId}
      rolling={rolling && state.turn === color}
      onRoll={handleRoll}
      name={names[color]}
    />
  )

  let status = `${names[state.turn]} is playing...`
  if (rolling) status = "Rolling..."
  else if (humanTurn) {
    if (!state.rolled) status = "Your turn! Tap the dice"
    else if (movable.length > 0) status = state.dice === 6 ? "Six! Tap a glowing pin" : "Tap a glowing pin to move"
    else if (movable.length === 0) status = state.sixes >= 3 ? "Three sixes! Turn lost" : "No moves available"
  }
  if (state.event === "cut") status = "Cut! Extra turn"

  return (
    <main className="relative flex min-h-dvh flex-col items-center justify-center overflow-hidden bg-[#0b3a8c] px-2 py-4">
      <div
        className="pointer-events-none absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: "url(/images/bg-dice.png)" }}
        aria-hidden="true"
      />
      <div className="relative flex w-full max-w-[min(96vw,calc(100dvh-14rem),540px)] flex-col gap-2">
        <div className="flex items-end justify-between">
          {panel("green", "left")}
          {panel("yellow", "right")}
        </div>

        <Board
          players={state.players}
          tokens={state.tokens}
          names={names}
          movable={humanTurn ? movable : []}
          turn={state.turn}
          onTokenClick={handleMove}
        />

        <div className="flex items-start justify-between">
          {panel("red", "left")}
          {panel("blue", "right")}
        </div>

        <div className="flex justify-center" aria-live="polite">
          <p
            className={`rounded-full px-4 py-1.5 text-center text-sm font-bold drop-shadow sm:text-base ${
              canRoll
                ? "turn-banner border-2 border-white bg-gradient-to-b from-[#ffd84d] to-[#ffb300] text-[#7a3d00] shadow-[0_3px_0_#b45309]"
                : "text-white"
            }`}
          >
            {status}
          </p>
        </div>
      </div>

      <button
        type="button"
        onClick={onExit}
        aria-label="Exit game"
        className="absolute bottom-3 left-3 flex h-10 w-10 items-center justify-center rounded-full border-2 border-[#f5c518] bg-gradient-to-b from-[#ff8a1f] to-[#e2560c] text-white shadow-lg"
      >
        <LogOut className="h-5 w-5 rotate-180" />
      </button>

      {state.gameOver && (
        <div className="absolute inset-0 z-[100] flex items-center justify-center bg-black/60 p-4" role="dialog" aria-modal="true">
          <div className="w-full max-w-sm rounded-2xl border-4 border-[#f5c518] bg-gradient-to-b from-[#2f7de1] to-[#123c94] p-6 text-center text-white shadow-2xl">
            <Trophy className="mx-auto h-14 w-14 text-[#ffd200]" />
            <h2 className="mt-2 text-3xl font-bold">{names[state.finished[0]]} wins!</h2>
            <ol className="mt-4 flex flex-col gap-2">
              {state.finished.map((c, i) => (
                <li key={c} className="flex items-center justify-between rounded-lg bg-white/15 px-4 py-2 font-semibold">
                  <span>#{i + 1}</span>
                  <span>{names[c]}</span>
                </li>
              ))}
            </ol>
            <div className="mt-6 flex gap-3">
              {onRestart && (
                <button
                  type="button"
                  onClick={onRestart}
                  className="flex-1 rounded-xl bg-[#ffd200] py-3 font-bold text-[#7a3d00] shadow-[0_4px_0_#b45309]"
                >
                  Play Again
                </button>
              )}
              <button
                type="button"
                onClick={onExit}
                className="flex-1 rounded-xl bg-white py-3 font-bold text-[#123c94] shadow-[0_4px_0_#9ca3af]"
              >
                Menu
              </button>
            </div>
          </div>
        </div>
      )}
    </main>
  )
}
